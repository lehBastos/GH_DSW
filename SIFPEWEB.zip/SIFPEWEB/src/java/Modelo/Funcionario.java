/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Leticia
 */
@Entity
@Table(name = "funcionario")
@NamedQueries({
    @NamedQuery(name = "Funcionario.findAll", query = "SELECT f FROM Funcionario f")
    , @NamedQuery(name = "Funcionario.findByIdFuncionario", query = "SELECT f FROM Funcionario f WHERE f.funcionarioPK.idFuncionario = :idFuncionario")
    , @NamedQuery(name = "Funcionario.findByMatCIEP", query = "SELECT f FROM Funcionario f WHERE f.matCIEP = :matCIEP")
    , @NamedQuery(name = "Funcionario.findByTipoUser", query = "SELECT f FROM Funcionario f WHERE f.tipoUser = :tipoUser")
    , @NamedQuery(name = "Funcionario.findByCondutoridCondutor", query = "SELECT f FROM Funcionario f WHERE f.funcionarioPK.condutoridCondutor = :condutoridCondutor")
    , @NamedQuery(name = "Funcionario.findByLogin", query = "SELECT f FROM Funcionario f WHERE f.login = :login")
    , @NamedQuery(name = "Funcionario.findBySenha", query = "SELECT f FROM Funcionario f WHERE f.senha = :senha")})
public class Funcionario implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected FuncionarioPK funcionarioPK;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "matCIEP")
    private String matCIEP;
    @Basic(optional = false)
    @NotNull
    @Column(name = "TipoUser")
    private int tipoUser;
    @Size(max = 10)
    @Column(name = "login")
    private String login;
    @Size(max = 6)
    @Column(name = "senha")
    private String senha;
    @JoinColumn(name = "Condutor_idCondutor", referencedColumnName = "idCondutor", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Condutor condutor;

    public Funcionario() {
    }

    public Funcionario(FuncionarioPK funcionarioPK) {
        this.funcionarioPK = funcionarioPK;
    }

    public Funcionario(FuncionarioPK funcionarioPK, String matCIEP, int tipoUser) {
        this.funcionarioPK = funcionarioPK;
        this.matCIEP = matCIEP;
        this.tipoUser = tipoUser;
    }

    public Funcionario(int idFuncionario, int condutoridCondutor) {
        this.funcionarioPK = new FuncionarioPK(idFuncionario, condutoridCondutor);
    }

    public FuncionarioPK getFuncionarioPK() {
        return funcionarioPK;
    }

    public void setFuncionarioPK(FuncionarioPK funcionarioPK) {
        this.funcionarioPK = funcionarioPK;
    }

    public String getMatCIEP() {
        return matCIEP;
    }

    public void setMatCIEP(String matCIEP) {
        this.matCIEP = matCIEP;
    }

    public int getTipoUser() {
        return tipoUser;
    }

    public void setTipoUser(int tipoUser) {
        this.tipoUser = tipoUser;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Condutor getCondutor() {
        return condutor;
    }

    public void setCondutor(Condutor condutor) {
        this.condutor = condutor;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (funcionarioPK != null ? funcionarioPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Funcionario)) {
            return false;
        }
        Funcionario other = (Funcionario) object;
        if ((this.funcionarioPK == null && other.funcionarioPK != null) || (this.funcionarioPK != null && !this.funcionarioPK.equals(other.funcionarioPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Modelo.Funcionario[ funcionarioPK=" + funcionarioPK + " ]";
    }
    
}
