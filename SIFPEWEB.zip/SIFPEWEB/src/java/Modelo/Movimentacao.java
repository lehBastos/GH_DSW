/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Leticia
 */
@Entity
@Table(name = "movimentacao")
@NamedQueries({
    @NamedQuery(name = "Movimentacao.findAll", query = "SELECT m FROM Movimentacao m")
    , @NamedQuery(name = "Movimentacao.findByDtEntrada", query = "SELECT m FROM Movimentacao m WHERE m.dtEntrada = :dtEntrada")
    , @NamedQuery(name = "Movimentacao.findByDtSaida", query = "SELECT m FROM Movimentacao m WHERE m.dtSaida = :dtSaida")
    , @NamedQuery(name = "Movimentacao.findByCarroidCarro", query = "SELECT m FROM Movimentacao m WHERE m.movimentacaoPK.carroidCarro = :carroidCarro")
    , @NamedQuery(name = "Movimentacao.findByCarroCondutoridCondutor", query = "SELECT m FROM Movimentacao m WHERE m.movimentacaoPK.carroCondutoridCondutor = :carroCondutoridCondutor")})
public class Movimentacao implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected MovimentacaoPK movimentacaoPK;
    @Column(name = "dtEntrada")
    @Temporal(TemporalType.DATE)
    private Date dtEntrada;
    @Column(name = "dtSaida")
    @Temporal(TemporalType.DATE)
    private Date dtSaida;
    @JoinColumns({
        @JoinColumn(name = "Carro_idCarro", referencedColumnName = "idCarro", insertable = false, updatable = false)
        , @JoinColumn(name = "Carro_Condutor_idCondutor", referencedColumnName = "Condutor_idCondutor", insertable = false, updatable = false)})
    @OneToOne(optional = false)
    private Carro carro;

    public Movimentacao() {
    }

    public Movimentacao(MovimentacaoPK movimentacaoPK) {
        this.movimentacaoPK = movimentacaoPK;
    }

    public Movimentacao(int carroidCarro, int carroCondutoridCondutor) {
        this.movimentacaoPK = new MovimentacaoPK(carroidCarro, carroCondutoridCondutor);
    }

    public MovimentacaoPK getMovimentacaoPK() {
        return movimentacaoPK;
    }

    public void setMovimentacaoPK(MovimentacaoPK movimentacaoPK) {
        this.movimentacaoPK = movimentacaoPK;
    }

    public Date getDtEntrada() {
        return dtEntrada;
    }

    public void setDtEntrada(Date dtEntrada) {
        this.dtEntrada = dtEntrada;
    }

    public Date getDtSaida() {
        return dtSaida;
    }

    public void setDtSaida(Date dtSaida) {
        this.dtSaida = dtSaida;
    }

    public Carro getCarro() {
        return carro;
    }

    public void setCarro(Carro carro) {
        this.carro = carro;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (movimentacaoPK != null ? movimentacaoPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Movimentacao)) {
            return false;
        }
        Movimentacao other = (Movimentacao) object;
        if ((this.movimentacaoPK == null && other.movimentacaoPK != null) || (this.movimentacaoPK != null && !this.movimentacaoPK.equals(other.movimentacaoPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Modelo.Movimentacao[ movimentacaoPK=" + movimentacaoPK + " ]";
    }
    
}
