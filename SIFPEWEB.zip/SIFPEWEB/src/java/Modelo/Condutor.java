/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Leticia
 */
@Entity
@Table(name = "condutor")
@NamedQueries({
    @NamedQuery(name = "Condutor.findAll", query = "SELECT c FROM Condutor c")})
public class Condutor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idcond;
    private String nome;
    private int fone;
    private String matricula;
    private String tipo;
    private int cnh;
    
    @OneToMany(mappedBy = "condutor")
    @NotNull
    private Carro carro;

    public Condutor() {
    }

    public Condutor(Integer idcond) {
        this.idcond = idcond;
    }

    public Condutor(Integer idcond, String nome, int fone, String matricula, String tipo, int cnh, Carro carro) {
        this.idcond = idcond;
        this.nome = nome;
        this.fone = fone;
        this.matricula = matricula;
        this.tipo = tipo;
        this.cnh = cnh;
        this.carro = carro;
    }

    public void setIdcond(Integer idcond) {
        this.idcond = idcond;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setFone(int fone) {
        this.fone = fone;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setCnh(int cnh) {
        this.cnh = cnh;
    }

    public void setCarro(Carro carro) {
        this.carro = carro;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.idcond);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Condutor other = (Condutor) obj;
        if (!Objects.equals(this.idcond, other.idcond)) {
            return false;
        }
        return true;
    }

    
    
}
