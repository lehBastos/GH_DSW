/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Leticia
 */
@Entity
@Table(name = "condutor")
@NamedQueries({
    @NamedQuery(name = "Condutor.findAll", query = "SELECT c FROM Condutor c")
    , @NamedQuery(name = "Condutor.findByIdCondutor", query = "SELECT c FROM Condutor c WHERE c.idCondutor = :idCondutor")
    , @NamedQuery(name = "Condutor.findByCnh", query = "SELECT c FROM Condutor c WHERE c.cnh = :cnh")
    , @NamedQuery(name = "Condutor.findByTelefone", query = "SELECT c FROM Condutor c WHERE c.telefone = :telefone")
    , @NamedQuery(name = "Condutor.findByNome", query = "SELECT c FROM Condutor c WHERE c.nome = :nome")})
public class Condutor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "idCondutor")
    private Integer idCondutor;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "CNH")
    private String cnh;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 11)
    @Column(name = "Telefone")
    private String telefone;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "Nome")
    private String nome;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "condutor")
    private List<Carro> carroList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "condutor")
    private List<Aluno> alunoList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "condutor")
    private List<Funcionario> funcionarioList;

    public Condutor() {
    }

    public Condutor(Integer idCondutor) {
        this.idCondutor = idCondutor;
    }

    public Condutor(Integer idCondutor, String cnh, String telefone, String nome) {
        this.idCondutor = idCondutor;
        this.cnh = cnh;
        this.telefone = telefone;
        this.nome = nome;
    }

    public Integer getIdCondutor() {
        return idCondutor;
    }

    public void setIdCondutor(Integer idCondutor) {
        this.idCondutor = idCondutor;
    }

    public String getCnh() {
        return cnh;
    }

    public void setCnh(String cnh) {
        this.cnh = cnh;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Carro> getCarroList() {
        return carroList;
    }

    public void setCarroList(List<Carro> carroList) {
        this.carroList = carroList;
    }

    public List<Aluno> getAlunoList() {
        return alunoList;
    }

    public void setAlunoList(List<Aluno> alunoList) {
        this.alunoList = alunoList;
    }

    public List<Funcionario> getFuncionarioList() {
        return funcionarioList;
    }

    public void setFuncionarioList(List<Funcionario> funcionarioList) {
        this.funcionarioList = funcionarioList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCondutor != null ? idCondutor.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Condutor)) {
            return false;
        }
        Condutor other = (Condutor) object;
        if ((this.idCondutor == null && other.idCondutor != null) || (this.idCondutor != null && !this.idCondutor.equals(other.idCondutor))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Modelo.Condutor[ idCondutor=" + idCondutor + " ]";
    }
    
}
