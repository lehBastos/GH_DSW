/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Leticia
 */
@Entity
@Table(name = "condutor")
@NamedQueries({
    @NamedQuery(name = "Condutor.findAll", query = "SELECT c FROM Condutor c")})
public class Condutor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "idcond")
    private Integer idcond;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "nome")
    private String nome;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "tipo")
    private String tipo;
    @Size(max = 20)
    @Column(name = "matricula")
    private String matricula;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cnh")
    private int cnh;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fone")
    private int fone;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "condutoridCond")
    private List<Carro> carroList;

    public Condutor() {
    }

    public Condutor(Integer idcond) {
        this.idcond = idcond;
    }

    public Condutor(Integer idcond, String nome, String tipo, int cnh, int fone) {
        this.idcond = idcond;
        this.nome = nome;
        this.tipo = tipo;
        this.cnh = cnh;
        this.fone = fone;
    }

    public Integer getIdcond() {
        return idcond;
    }

    public void setIdcond(Integer idcond) {
        this.idcond = idcond;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public int getCnh() {
        return cnh;
    }

    public void setCnh(int cnh) {
        this.cnh = cnh;
    }

    public int getFone() {
        return fone;
    }

    public void setFone(int fone) {
        this.fone = fone;
    }

    public List<Carro> getCarroList() {
        return carroList;
    }

    public void setCarroList(List<Carro> carroList) {
        this.carroList = carroList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idcond != null ? idcond.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Condutor)) {
            return false;
        }
        Condutor other = (Condutor) object;
        if ((this.idcond == null && other.idcond != null) || (this.idcond != null && !this.idcond.equals(other.idcond))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Modelo.Condutor[ idcond=" + idcond + " ]";
    }
    
}
