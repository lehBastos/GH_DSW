/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Leticia
 */
@Entity
@Table(name = "carro")
@NamedQueries({
    @NamedQuery(name = "Carro.findAll", query = "SELECT c FROM Carro c")
    , @NamedQuery(name = "Carro.findByIdCarro", query = "SELECT c FROM Carro c WHERE c.carroPK.idCarro = :idCarro")
    , @NamedQuery(name = "Carro.findByPlacaCarro", query = "SELECT c FROM Carro c WHERE c.placaCarro = :placaCarro")
    , @NamedQuery(name = "Carro.findByModeloCarro", query = "SELECT c FROM Carro c WHERE c.modeloCarro = :modeloCarro")
    , @NamedQuery(name = "Carro.findByFabCarro", query = "SELECT c FROM Carro c WHERE c.fabCarro = :fabCarro")
    , @NamedQuery(name = "Carro.findByCorCarro", query = "SELECT c FROM Carro c WHERE c.corCarro = :corCarro")
    , @NamedQuery(name = "Carro.findByCondutoridCondutor", query = "SELECT c FROM Carro c WHERE c.carroPK.condutoridCondutor = :condutoridCondutor")})
public class Carro implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CarroPK carroPK;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 7)
    @Column(name = "placaCarro")
    private String placaCarro;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "modeloCarro")
    private String modeloCarro;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "fabCarro")
    private String fabCarro;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 25)
    @Column(name = "corCarro")
    private String corCarro;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "carro")
    private Movimentacao movimentacao;
    @JoinColumn(name = "Condutor_idCondutor", referencedColumnName = "idCondutor", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Condutor condutor;

    public Carro() {
    }

    public Carro(CarroPK carroPK) {
        this.carroPK = carroPK;
    }

    public Carro(CarroPK carroPK, String placaCarro, String modeloCarro, String fabCarro, String corCarro) {
        this.carroPK = carroPK;
        this.placaCarro = placaCarro;
        this.modeloCarro = modeloCarro;
        this.fabCarro = fabCarro;
        this.corCarro = corCarro;
    }

    public Carro(int idCarro, int condutoridCondutor) {
        this.carroPK = new CarroPK(idCarro, condutoridCondutor);
    }

    public CarroPK getCarroPK() {
        return carroPK;
    }

    public void setCarroPK(CarroPK carroPK) {
        this.carroPK = carroPK;
    }

    public String getPlacaCarro() {
        return placaCarro;
    }

    public void setPlacaCarro(String placaCarro) {
        this.placaCarro = placaCarro;
    }

    public String getModeloCarro() {
        return modeloCarro;
    }

    public void setModeloCarro(String modeloCarro) {
        this.modeloCarro = modeloCarro;
    }

    public String getFabCarro() {
        return fabCarro;
    }

    public void setFabCarro(String fabCarro) {
        this.fabCarro = fabCarro;
    }

    public String getCorCarro() {
        return corCarro;
    }

    public void setCorCarro(String corCarro) {
        this.corCarro = corCarro;
    }

    public Movimentacao getMovimentacao() {
        return movimentacao;
    }

    public void setMovimentacao(Movimentacao movimentacao) {
        this.movimentacao = movimentacao;
    }

    public Condutor getCondutor() {
        return condutor;
    }

    public void setCondutor(Condutor condutor) {
        this.condutor = condutor;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (carroPK != null ? carroPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Carro)) {
            return false;
        }
        Carro other = (Carro) object;
        if ((this.carroPK == null && other.carroPK != null) || (this.carroPK != null && !this.carroPK.equals(other.carroPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Modelo.Carro[ carroPK=" + carroPK + " ]";
    }
    
}
