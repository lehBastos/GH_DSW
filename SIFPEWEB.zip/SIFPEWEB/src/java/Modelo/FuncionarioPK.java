/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Leticia
 */
@Embeddable
public class FuncionarioPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "idFuncionario")
    private int idFuncionario;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Condutor_idCondutor")
    private int condutoridCondutor;

    public FuncionarioPK() {
    }

    public FuncionarioPK(int idFuncionario, int condutoridCondutor) {
        this.idFuncionario = idFuncionario;
        this.condutoridCondutor = condutoridCondutor;
    }

    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public int getCondutoridCondutor() {
        return condutoridCondutor;
    }

    public void setCondutoridCondutor(int condutoridCondutor) {
        this.condutoridCondutor = condutoridCondutor;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) idFuncionario;
        hash += (int) condutoridCondutor;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof FuncionarioPK)) {
            return false;
        }
        FuncionarioPK other = (FuncionarioPK) object;
        if (this.idFuncionario != other.idFuncionario) {
            return false;
        }
        if (this.condutoridCondutor != other.condutoridCondutor) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Modelo.FuncionarioPK[ idFuncionario=" + idFuncionario + ", condutoridCondutor=" + condutoridCondutor + " ]";
    }
    
}
