/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Leticia
 */
@Embeddable
public class AcessoPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "user_id")
    private int userId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "carro_id")
    private int carroId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "condutor_id")
    private int condutorId;

    public AcessoPK() {
    }

    public AcessoPK(int userId, int carroId, int condutorId) {
        this.userId = userId;
        this.carroId = carroId;
        this.condutorId = condutorId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getCarroId() {
        return carroId;
    }

    public void setCarroId(int carroId) {
        this.carroId = carroId;
    }

    public int getCondutorId() {
        return condutorId;
    }

    public void setCondutorId(int condutorId) {
        this.condutorId = condutorId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) userId;
        hash += (int) carroId;
        hash += (int) condutorId;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AcessoPK)) {
            return false;
        }
        AcessoPK other = (AcessoPK) object;
        if (this.userId != other.userId) {
            return false;
        }
        if (this.carroId != other.carroId) {
            return false;
        }
        if (this.condutorId != other.condutorId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Modelo.AcessoPK[ userId=" + userId + ", carroId=" + carroId + ", condutorId=" + condutorId + " ]";
    }
    
}
