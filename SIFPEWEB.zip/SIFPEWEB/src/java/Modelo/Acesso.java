/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Leticia
 */
@Entity
@Table(name = "acesso")
@NamedQueries({
    @NamedQuery(name = "Acesso.findAll", query = "SELECT a FROM Acesso a")})
public class Acesso implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "idacesso")
    private Integer idacesso;
    @Basic(optional = false)
    @NotNull
    @Column(name = "dtEntrada")
    @Temporal(TemporalType.DATE)
    private Date dtEntrada;
    @Basic(optional = false)
    @NotNull
    @Column(name = "horaEntrada")
    @Temporal(TemporalType.DATE)
    private Date horaEntrada;
    @Column(name = "dtSaida")
    @Temporal(TemporalType.DATE)
    private Date dtSaida;
    @Column(name = "horaSaida")
    @Temporal(TemporalType.DATE)
    private Date horaSaida;
    @JoinColumn(name = "carro_idcarro", referencedColumnName = "idcarro")
    @ManyToOne(optional = false)
    private Carro carroIdcarro;
    @JoinColumn(name = "usuario_iduser", referencedColumnName = "iduser")
    @ManyToOne(optional = false)
    private Usuario usuarioIduser;

    public Acesso() {
    }

    public Acesso(Integer idacesso) {
        this.idacesso = idacesso;
    }

    public Acesso(Integer idacesso, Date dtEntrada, Date horaEntrada) {
        this.idacesso = idacesso;
        this.dtEntrada = dtEntrada;
        this.horaEntrada = horaEntrada;
    }

    public Integer getIdacesso() {
        return idacesso;
    }

    public void setIdacesso(Integer idacesso) {
        this.idacesso = idacesso;
    }

    public Date getDtEntrada() {
        return dtEntrada;
    }

    public void setDtEntrada(Date dtEntrada) {
        this.dtEntrada = dtEntrada;
    }

    public Date getHoraEntrada() {
        return horaEntrada;
    }

    public void setHoraEntrada(Date horaEntrada) {
        this.horaEntrada = horaEntrada;
    }

    public Date getDtSaida() {
        return dtSaida;
    }

    public void setDtSaida(Date dtSaida) {
        this.dtSaida = dtSaida;
    }

    public Date getHoraSaida() {
        return horaSaida;
    }

    public void setHoraSaida(Date horaSaida) {
        this.horaSaida = horaSaida;
    }

    public Carro getCarroIdcarro() {
        return carroIdcarro;
    }

    public void setCarroIdcarro(Carro carroIdcarro) {
        this.carroIdcarro = carroIdcarro;
    }

    public Usuario getUsuarioIduser() {
        return usuarioIduser;
    }

    public void setUsuarioIduser(Usuario usuarioIduser) {
        this.usuarioIduser = usuarioIduser;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idacesso != null ? idacesso.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Acesso)) {
            return false;
        }
        Acesso other = (Acesso) object;
        if ((this.idacesso == null && other.idacesso != null) || (this.idacesso != null && !this.idacesso.equals(other.idacesso))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Modelo.Acesso[ idacesso=" + idacesso + " ]";
    }
    
}
