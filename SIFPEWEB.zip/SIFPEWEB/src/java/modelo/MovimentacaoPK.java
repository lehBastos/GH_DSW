/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Leticia
 */
@Embeddable
public class MovimentacaoPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "Carro_idCarro")
    private int carroidCarro;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Carro_Condutor_idCondutor")
    private int carroCondutoridCondutor;

    public MovimentacaoPK() {
    }

    public MovimentacaoPK(int carroidCarro, int carroCondutoridCondutor) {
        this.carroidCarro = carroidCarro;
        this.carroCondutoridCondutor = carroCondutoridCondutor;
    }

    public int getCarroidCarro() {
        return carroidCarro;
    }

    public void setCarroidCarro(int carroidCarro) {
        this.carroidCarro = carroidCarro;
    }

    public int getCarroCondutoridCondutor() {
        return carroCondutoridCondutor;
    }

    public void setCarroCondutoridCondutor(int carroCondutoridCondutor) {
        this.carroCondutoridCondutor = carroCondutoridCondutor;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) carroidCarro;
        hash += (int) carroCondutoridCondutor;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof MovimentacaoPK)) {
            return false;
        }
        MovimentacaoPK other = (MovimentacaoPK) object;
        if (this.carroidCarro != other.carroidCarro) {
            return false;
        }
        if (this.carroCondutoridCondutor != other.carroCondutoridCondutor) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.MovimentacaoPK[ carroidCarro=" + carroidCarro + ", carroCondutoridCondutor=" + carroCondutoridCondutor + " ]";
    }
    
}
