/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Leticia
 */
@Embeddable
public class AlunoPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "idAluno")
    private int idAluno;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Condutor_idCondutor")
    private int condutoridCondutor;

    public AlunoPK() {
    }

    public AlunoPK(int idAluno, int condutoridCondutor) {
        this.idAluno = idAluno;
        this.condutoridCondutor = condutoridCondutor;
    }

    public int getIdAluno() {
        return idAluno;
    }

    public void setIdAluno(int idAluno) {
        this.idAluno = idAluno;
    }

    public int getCondutoridCondutor() {
        return condutoridCondutor;
    }

    public void setCondutoridCondutor(int condutoridCondutor) {
        this.condutoridCondutor = condutoridCondutor;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) idAluno;
        hash += (int) condutoridCondutor;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AlunoPK)) {
            return false;
        }
        AlunoPK other = (AlunoPK) object;
        if (this.idAluno != other.idAluno) {
            return false;
        }
        if (this.condutoridCondutor != other.condutoridCondutor) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.AlunoPK[ idAluno=" + idAluno + ", condutoridCondutor=" + condutoridCondutor + " ]";
    }
    
}
