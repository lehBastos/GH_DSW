/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Leticia
 */
@Embeddable
public class CarroPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "idCarro")
    private int idCarro;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Condutor_idCondutor")
    private int condutoridCondutor;

    public CarroPK() {
    }

    public CarroPK(int idCarro, int condutoridCondutor) {
        this.idCarro = idCarro;
        this.condutoridCondutor = condutoridCondutor;
    }

    public int getIdCarro() {
        return idCarro;
    }

    public void setIdCarro(int idCarro) {
        this.idCarro = idCarro;
    }

    public int getCondutoridCondutor() {
        return condutoridCondutor;
    }

    public void setCondutoridCondutor(int condutoridCondutor) {
        this.condutoridCondutor = condutoridCondutor;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) idCarro;
        hash += (int) condutoridCondutor;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CarroPK)) {
            return false;
        }
        CarroPK other = (CarroPK) object;
        if (this.idCarro != other.idCarro) {
            return false;
        }
        if (this.condutoridCondutor != other.condutoridCondutor) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.CarroPK[ idCarro=" + idCarro + ", condutoridCondutor=" + condutoridCondutor + " ]";
    }
    
}
